import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { FaWhatsapp } from "react-icons/fa";

export default function ConfeitariaSite() {
  const [pedido, setPedido] = useState({ nome: "", tamanho: "", recheio: "", quantidade: "", retirada: true, endereco: "" });
  const [estoque, setEstoque] = useState({
    "250g": 10,
    "350g": 10,
    "500g": 10,
  });
  const [precos, setPrecos] = useState({
    "250g": "39,90",
    "350g": "46,90",
    "500g": "54,90",
  });
  const [modoAdmin, setModoAdmin] = useState(false);

  const recheiosDisponiveis = [
    "Brigadeiro Gourmet",
    "Ninho com Nutella",
    "Beijinho",
    "Doce de leite com nozes",
    "Oreo",
    "Morango"
  ];

  const gerarLinkWhatsApp = () => {
    const msg = \`Olá! Meu nome é \${pedido.nome}.
Quero pedir: \${pedido.quantidade}x Ovo de colher \${pedido.tamanho} recheado com \${pedido.recheio}.
Forma de recebimento: \${pedido.retirada ? "Retirada" : \`Entrega no endereço: \${pedido.endereco}\`}\`;
    return \`https://wa.me/55SEUNUMEROAQUI?text=\${encodeURIComponent(msg)}\`;
  };

  const enviarPedido = () => {
    if (pedido.tamanho in estoque && Number(pedido.quantidade) > 0) {
      const novaQtd = estoque[pedido.tamanho] - Number(pedido.quantidade);
      if (novaQtd >= 0) {
        setEstoque({ ...estoque, [pedido.tamanho]: novaQtd });
        window.open(gerarLinkWhatsApp(), '_blank');
      } else {
        alert("Quantidade solicitada maior que o estoque disponível.");
      }
    } else {
      alert("Tamanho inválido ou fora de estoque.");
    }
  };

  return (
    <div className="min-h-screen bg-white text-gray-800 p-4 max-w-xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-4">Confeitaria da JU</h1>
      <p className="text-center mb-6">Doces artesanais feitos com carinho ❤️</p>

      <div className="text-right mb-2">
        <Button variant="outline" onClick={() => setModoAdmin(!modoAdmin)}>
          {modoAdmin ? "Sair do modo admin" : "Entrar no modo admin"}
        </Button>
      </div>

      {modoAdmin && (
        <Card className="mb-6">
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Painel Administrativo</h2>
            {Object.keys(precos).map((tamanho) => (
              <div key={tamanho} className="mb-2">
                <label className="block text-sm font-medium">Preço do ovo {tamanho}</label>
                <Input
                  value={precos[tamanho]}
                  onChange={(e) => setPrecos({ ...precos, [tamanho]: e.target.value })}
                />
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Card className="mb-6">
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold mb-2">Cardápio</h2>
          <ul className="space-y-2">
            {Object.entries(estoque).map(([tamanho, qtd]) => (
              <li key={tamanho}>
                <strong>Ovo de colher {tamanho}</strong> - R$ {precos[tamanho]} (Disponível: {qtd})
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardContent className="p-4 space-y-2">
          <h2 className="text-xl font-semibold mb-2">Faça seu pedido</h2>
          <Input placeholder="Seu nome" value={pedido.nome} onChange={(e) => setPedido({ ...pedido, nome: e.target.value })} />
          <Input placeholder="Tamanho (250g, 350g ou 500g)" value={pedido.tamanho} onChange={(e) => setPedido({ ...pedido, tamanho: e.target.value })} />
          <select className="w-full p-2 border rounded" value={pedido.recheio} onChange={(e) => setPedido({ ...pedido, recheio: e.target.value })}>
            <option value="">Selecione o recheio</option>
            {recheiosDisponiveis.map(recheio => (
              <option key={recheio} value={recheio}>{recheio}</option>
            ))}
          </select>
          <Input placeholder="Quantidade" value={pedido.quantidade} onChange={(e) => setPedido({ ...pedido, quantidade: e.target.value })} />

          <div className="flex items-center gap-2">
            <label><input type="radio" checked={pedido.retirada} onChange={() => setPedido({ ...pedido, retirada: true })} /> Retirada</label>
            <label><input type="radio" checked={!pedido.retirada} onChange={() => setPedido({ ...pedido, retirada: false })} /> Entrega</label>
          </div>

          {!pedido.retirada && (
            <Textarea placeholder="Endereço para entrega" value={pedido.endereco} onChange={(e) => setPedido({ ...pedido, endereco: e.target.value })} />
          )}

          <Button className="w-full mt-2" onClick={enviarPedido}>
            <FaWhatsapp className="mr-2" /> Enviar pedido pelo WhatsApp
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold mb-2">Sobre</h2>
          <p>
            A Confeitaria da JU é feita com amor por uma confeiteira apaixonada por doces! Trabalhamos com
            retirada e entrega para facilitar sua vida.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
