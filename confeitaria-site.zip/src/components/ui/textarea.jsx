export function Textarea(props) {
  return <textarea className='border px-2 py-1 rounded w-full' {...props} />;
}